create view PLACE_MINIMALNE as
select id_prac, nazwisko, etat, placa_pod
from pracownicy
where placa_pod < 700
order by nazwisko
WITH CHECK OPTION
/

