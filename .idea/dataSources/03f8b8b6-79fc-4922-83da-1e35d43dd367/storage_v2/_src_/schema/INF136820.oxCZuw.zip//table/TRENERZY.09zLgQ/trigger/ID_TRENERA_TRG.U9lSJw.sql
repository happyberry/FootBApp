create trigger ID_TRENERA_TRG
    before insert
    on TRENERZY
    for each row
    when (new.id_trenera IS NULL)
BEGIN
    :new.id_trenera := id_trenera_seq.nextval;
END;
/

