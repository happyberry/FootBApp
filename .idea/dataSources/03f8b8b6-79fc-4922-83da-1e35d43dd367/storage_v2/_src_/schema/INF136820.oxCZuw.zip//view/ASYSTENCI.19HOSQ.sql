create view ASYSTENCI (NAZWISKO, PLACA, STAZ) as
select nazwisko, placa_pod+NVL(placa_dod,0), EXTRACT (YEAR FROM((DATE '2019-01-01' - zatrudniony) YEAR TO MONTH))
from pracownicy
where etat = 'ASYSTENT'
/

