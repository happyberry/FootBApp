create view PLACE (ID_ZESP, SREDNIA, MINIMUM, MAXIMUM, FUNDUSZ, L_PENSJI, L_DODATKOW) as
select id_zesp, avg(placa_pod+nvl(placa_dod,0)), min(placa_pod+nvl(placa_dod,0)), max(placa_pod+nvl(placa_dod,0)),
sum(placa_pod+nvl(placa_dod,0)), count(placa_pod), count(placa_dod)
from pracownicy
group by id_zesp
order by id_zesp
/

