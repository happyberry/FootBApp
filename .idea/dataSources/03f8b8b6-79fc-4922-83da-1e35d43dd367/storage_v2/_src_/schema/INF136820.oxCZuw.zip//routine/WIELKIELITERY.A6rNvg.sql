create FUNCTION wielkieLitery
 (pID IN pracownicy.id_prac%TYPE,
  pWynik OUT pracownicy.nazwisko%TYPE)
 RETURN NUMBER IS
 vRezultat NUMBER;
 vPracownik pracownicy.nazwisko%TYPE;
BEGIN
 SELECT nazwisko INTO
 vPracownik
 FROM pracownicy
 WHERE id_prac = pID;
  vRezultat := 1;
  pWynik := UPPER(vPracownik);
 RETURN vRezultat;
EXCEPTION
 WHEN NO_DATA_FOUND THEN
 vRezultat := 0;
 RETURN vRezultat;
END wielkieLitery;
/

