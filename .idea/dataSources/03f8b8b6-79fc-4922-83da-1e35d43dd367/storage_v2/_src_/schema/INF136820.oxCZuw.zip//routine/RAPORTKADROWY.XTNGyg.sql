create PROCEDURE RaportKadrowy IS
 CURSOR cPracownicyEtatu (pNazwaEtatu VARCHAR) IS
  SELECT nazwisko, placa_pod + nvl(placa_dod,0) AS pensja
  FROM pracownicy
  WHERE etat = pNazwaEtatu;
 CURSOR cEtaty IS
  SELECT nazwa
  FROM etaty;
 vSrednia NUMBER;
 vLicznik NUMBER;
BEGIN
 FOR vEtat IN cEtaty LOOP
  DBMS_OUTPUT.PUT_LINE('Etat: ' || vEtat.nazwa);
  DBMS_OUTPUT.PUT_LINE('---------------------------');
  vSrednia := 0;
  vLicznik := 0;
  FOR vPracownik IN cPracownicyEtatu(vEtat.nazwa) LOOP
   DBMS_OUTPUT.PUT_LINE(cPracownicyEtatu%ROWCOUNT || '. ' || vPracownik.nazwisko || ', pensja: ' || vPracownik.pensja);
   vLicznik := cPracownicyEtatu%ROWCOUNT;
   vSrednia := vSrednia + vPracownik.pensja;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('Liczba pracownikow: ' || vLicznik);
  IF vLicznik != 0 THEN
   vSrednia := vSrednia/vLicznik;
   DBMS_OUTPUT.PUT_LINE('Srednia pensja: ' || vSrednia);
  ELSE
   DBMS_OUTPUT.PUT_LINE('Brak' || vSrednia);
  END IF;
  DBMS_OUTPUT.NEW_LINE;
 END LOOP;
END RaportKadrowy;


--EXEC RaportKadrowy;
/

