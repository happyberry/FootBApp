create PROCEDURE Obniz IS
BEGIN
 UPDATE Pracownicy
 SET placa_pod = placa_pod / 1.1;
END Obniz;

/*
EXECUTE Obniz;
*/
/

