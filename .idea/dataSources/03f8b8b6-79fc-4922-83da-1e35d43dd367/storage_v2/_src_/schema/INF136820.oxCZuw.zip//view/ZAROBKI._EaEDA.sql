create view ZAROBKI as
select p.id_prac, p.nazwisko, p.etat, p.placa_pod
from pracownicy p join pracownicy s on p.id_szefa = s.id_prac
where p.placa_pod < s.placa_pod
WITH CHECK OPTION
/

