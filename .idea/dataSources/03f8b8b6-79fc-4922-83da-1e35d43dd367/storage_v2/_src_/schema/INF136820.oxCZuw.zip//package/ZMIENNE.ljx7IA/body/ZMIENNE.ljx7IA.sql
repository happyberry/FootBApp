create PACKAGE BODY Zmienne IS
 --vLicznik NUMBER;
 PROCEDURE ZwiekszLicznik IS
 BEGIN
  vLicznik := vLicznik + 1;
  dbms_output.put_line('Zwiekszono');
 END ZwiekszLicznik;

 PROCEDURE ZmniejszLicznik IS
 BEGIN
  vLicznik := vLicznik - 1;
  dbms_output.put_line('Zmniejszono');
 END ZmniejszLicznik;

 FUNCTION PokazLicznik
 RETURN NUMBER IS
 BEGIN
  RETURN vLicznik;
 END PokazLicznik;

BEGIN
 vLicznik := 1;
 dbms_output.put_line('Zainicjalizowano');
END Zmienne;
/

