create view PRAC20 as
select nazwisko, placa_pod
from pracownicy
where id_zesp = 20
/

