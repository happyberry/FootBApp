create PROCEDURE NowyPracownik
(pNazwisko IN VARCHAR,
pNazwa IN VARCHAR,
pNazwiskoS IN VARCHAR,
pPlaca IN NUMBER) IS
BEGIN
INSERT INTO pracownicy
VALUES(myseq.NEXTVAL, pNazwisko, 'STAZYSTA', (SELECT id_prac 
                                  FROM pracownicy
                                  WHERE nazwisko = pNazwiskoS), SYSDATE, pPlaca, NULL, (SELECT id_zesp
                                                                                     FROM zespoly
                                                                                     WHERE nazwa = pNazwa));
END NowyPracownik;

--EXEC NowyPracownik('DYNDALSKI','ALGORYTMY','BLAZEWICZ',250);
/

