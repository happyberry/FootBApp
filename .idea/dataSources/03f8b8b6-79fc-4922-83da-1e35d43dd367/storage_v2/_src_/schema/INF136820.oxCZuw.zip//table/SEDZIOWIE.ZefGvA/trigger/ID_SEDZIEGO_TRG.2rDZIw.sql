create trigger ID_SEDZIEGO_TRG
    before insert
    on SEDZIOWIE
    for each row
    when (new.id_sedziego IS NULL)
BEGIN
    :new.id_sedziego := id_sedziego_seq.nextval;
END;
/

