create trigger GOLE_GOL_ID_TRG
    before insert
    on GOLE
    for each row
    when (new.gol_id IS NULL)
BEGIN
    :new.gol_id := gole_gol_id_seq.nextval;
END;
/

