create trigger ZAMIASTDELETE
    instead of delete
    on SZEFOWIE
    for each row
DECLARE
 vIdSzefa pracownicy.id_prac%type;
 NIEDOZWOLONE_USUWANIE EXCEPTION;
 PRAGMA EXCEPTION_INIT(NIEDOZWOLONE_USUWANIE, -2292);
BEGIN
 SELECT id_prac
 INTO vIdSzefa
 FROM pracownicy
 WHERE nazwisko = :OLD.szef;
 DELETE FROM pracownicy
 WHERE id_szefa = vIdSzefa OR id_prac = vIdSzefa;
EXCEPTION
 WHEN NIEDOZWOLONE_USUWANIE THEN
 RAISE_APPLICATION_ERROR(-20001, 'Jeden z podwładnych
usuwanego pracownika jest szefem innych pracowników. Usuwanie anulowane!');
END;
/

