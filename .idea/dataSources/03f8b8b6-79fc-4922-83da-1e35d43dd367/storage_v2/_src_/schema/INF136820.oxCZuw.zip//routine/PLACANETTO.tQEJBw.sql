create FUNCTION PlacaNetto
 (pBrutto IN NUMBER,
  pStawka IN NUMBER := 20)
 RETURN NUMBER IS
 vNetto NUMBER;
BEGIN
 vNetto := pBrutto - (pStawka/100)*pBrutto;
 RETURN vNetto;
END PlacaNetto;
/

