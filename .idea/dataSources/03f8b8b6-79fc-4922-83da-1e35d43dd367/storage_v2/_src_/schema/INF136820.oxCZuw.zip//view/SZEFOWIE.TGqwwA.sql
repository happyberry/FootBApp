create view SZEFOWIE (SZEF, PRACOWNICY) as
SELECT s.nazwisko, COUNT(p.id_prac)
 FROM Pracownicy p JOIN Pracownicy s ON p.id_szefa = s.id_prac
 GROUP BY s.nazwisko
/

create trigger ZAMIASTDELETE
    instead of delete
    on SZEFOWIE
    for each row
-- missing source code
/

