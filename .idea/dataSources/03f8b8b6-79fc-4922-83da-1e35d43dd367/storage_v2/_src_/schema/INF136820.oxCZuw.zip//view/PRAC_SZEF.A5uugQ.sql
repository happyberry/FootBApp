create view PRAC_SZEF as
select p.id_prac, p.id_szefa, p.nazwisko, p.etat, s.nazwisko
from pracownicy p join pracownicy s on p.id_szefa = s.id_prac
/

