create trigger ID_PILKARZA_TRG
    before insert
    on PILKARZE
    for each row
    when (new.id_pilkarza IS NULL)
BEGIN
    :new.id_pilkarza := id_pilkarza_seq.nextval;
END;
/

