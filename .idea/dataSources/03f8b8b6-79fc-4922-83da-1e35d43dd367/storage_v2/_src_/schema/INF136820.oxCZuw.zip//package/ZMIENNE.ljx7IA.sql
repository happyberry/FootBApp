create PACKAGE Zmienne IS
 vLicznik NUMBER := 0;
 PROCEDURE ZwiekszLicznik;
 PROCEDURE ZmniejszLicznik;
 FUNCTION PokazLicznik
 RETURN NUMBER;
END Zmienne;
/

