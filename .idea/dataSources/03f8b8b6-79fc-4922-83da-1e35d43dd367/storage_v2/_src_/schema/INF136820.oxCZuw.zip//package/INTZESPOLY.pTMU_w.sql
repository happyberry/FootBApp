create PACKAGE IntZespoly IS
 PROCEDURE DodajZespol(Id NUMBER, Nazwa VARCHAR, Adres VARCHAR); 
 PROCEDURE UsunPoId(Id NUMBER);
 PROCEDURE UsunPoNazwie(Nazwa VARCHAR);
 PROCEDURE ZmienDane(Id NUMBER, NowaNazwa VARCHAR, NowyAdres VARCHAR);
 FUNCTION PokazId(Nazwa VARCHAR) RETURN zespoly.id_zesp%TYPE;
 FUNCTION PokazNazwe(Id NUMBER) RETURN zespoly.nazwa%TYPE;
 FUNCTION PokazAdres(Id NUMBER) RETURN zespoly.adres%TYPE;
END IntZespoly;

/*
CREATE OR REPLACE PACKAGE BODY IntZespoly IS

 PROCEDURE DodajZespol
 (Id NUMBER,
 Nazwa VARCHAR,
 Adres VARCHAR)IS
 BEGIN
  INSERT INTO zespoly
  VALUES(Id, Nazwa, Adres);
  IF SQL%FOUND THEN
   DBMS_OUTPUT.PUT_LINE ('Dodanych rekordów: '|| SQL%ROWCOUNT);
  ELSE
   DBMS_OUTPUT.PUT_LINE ('Nie wstawiono żadnego rekordu!');
  END IF;
 END DodajZespol;

 PROCEDURE UsunPoId
 (Id NUMBER)IS
 BEGIN
  IF Id NOT IN (SELECT id_zesp FROM pracownicy) THEN
  RAISE_APPLICATION_ERROR(-20001, 'Zespol o podanym ID nie istnieje');
  DELETE FROM zespoly
  WHERE id_zesp = Id;
  DBMS_OUTPUT.PUT_LINE('Liczba usuniętych rekordów: '|| SQL%ROWCOUNT);
 END UsunPoId;

 PROCEDURE UsunPoNazwie
 (Nazwa VARCHAR)IS
 BEGIN
  DELETE FROM zespoly
  WHERE nazwa = Nazwa;
  DBMS_OUTPUT.PUT_LINE('Liczba usuniętych rekordów: '|| SQL%ROWCOUNT);
 END UsunPoNazwie;

 PROCEDURE ZmienDane
 (Id NUMBER, 
 NowaNazwa VARCHAR, 
 NowyAdres VARCHAR)IS
 BEGIN
  UPDATE zespoly
  SET nazwa = NowaNazwa,
  adres = NowyAdres
  WHERE id_zesp = Id;
  IF SQL%FOUND THEN
   DBMS_OUTPUT.PUT_LINE ('Zmodyfikowanych rekordow: '|| SQL%ROWCOUNT);
  ELSE
   DBMS_OUTPUT.PUT_LINE ('Nie zmodyfikowano żadnego rekordu!');
  END IF;
 END ZmienDane;

 FUNCTION PokazId
 (Nazwa VARCHAR) RETURN zespoly.id_zesp%TYPE IS
 vId zespoly.id_zesp%TYPE;
 BEGIN
  SELECT id_zesp 
  INTO vId
  FROM zespoly 
  WHERE nazwa = Nazwa;
  RETURN vId;
 END PokazId;

 FUNCTION PokazNazwe
 (Id NUMBER) RETURN zespoly.nazwa%TYPE IS
 vNazwa zespoly.nazwa%TYPE;
 BEGIN
  SELECT nazwa 
  INTO vNazwa 
  FROM zespoly 
  WHERE id_zesp = Id;
  RETURN vNazwa;
 END PokazNazwe;

 FUNCTION PokazAdres
 (Id NUMBER) RETURN zespoly.adres%TYPE IS
 vAdres zespoly.adres%TYPE;
 BEGIN
  SELECT adres 
  INTO vAdres 
  FROM zespoly
  WHERE id_zesp = Id;
  RETURN vAdres;
 END PokazAdres;

END IntZespoly;

*/
/

