create trigger MECZE_MECZ_ID_TRG
    before insert
    on MECZE
    for each row
    when (new.mecz_id IS NULL)
BEGIN
    :new.mecz_id := mecze_mecz_id_seq.nextval;
END;
/

