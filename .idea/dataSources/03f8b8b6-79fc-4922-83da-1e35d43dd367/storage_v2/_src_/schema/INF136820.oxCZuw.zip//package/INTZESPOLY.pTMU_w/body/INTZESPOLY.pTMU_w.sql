create PACKAGE BODY IntZespoly IS

 PROCEDURE DodajZespol
 (Id NUMBER,
 Nazwa VARCHAR,
 Adres VARCHAR)IS
 BEGIN
  INSERT INTO zespoly
  VALUES(Id, Nazwa, Adres);
  IF SQL%FOUND THEN
   DBMS_OUTPUT.PUT_LINE ('Dodanych rekordów: '|| SQL%ROWCOUNT);
  ELSE
   DBMS_OUTPUT.PUT_LINE ('Nie wstawiono żadnego rekordu!');
  END IF;
 EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
  DBMS_OUTPUT.PUT_LINE('Zespol o podanym ID juz istnieje');
 END DodajZespol;

 PROCEDURE UsunPoId
 (Id NUMBER)IS
 BEGIN
  DELETE FROM zespoly
  WHERE id_zesp = Id;
  IF SQL%ROWCOUNT = 0 THEN
   RAISE_APPLICATION_ERROR(-20001, 'Zespol o podanym ID nie istnieje');
  END IF;
  DBMS_OUTPUT.PUT_LINE('Liczba usuniętych rekordów: '|| SQL%ROWCOUNT);
 END UsunPoId;

 PROCEDURE UsunPoNazwie
 (Nazwa VARCHAR)IS
 BEGIN
  DELETE FROM zespoly
  WHERE nazwa = Nazwa;
  IF SQL%ROWCOUNT = 0 THEN
   RAISE_APPLICATION_ERROR(-20002, 'Zespol o podanej nazwie nie istnieje');
  END IF;
  DBMS_OUTPUT.PUT_LINE('Liczba usuniętych rekordów: '|| SQL%ROWCOUNT);
 END UsunPoNazwie;

 PROCEDURE ZmienDane
 (Id NUMBER, 
 NowaNazwa VARCHAR, 
 NowyAdres VARCHAR)IS
 BEGIN
  UPDATE zespoly
  SET nazwa = NowaNazwa,
  adres = NowyAdres
  WHERE id_zesp = Id;
  IF SQL%FOUND THEN
   DBMS_OUTPUT.PUT_LINE ('Zmodyfikowanych rekordow: '|| SQL%ROWCOUNT);
  ELSE
   DBMS_OUTPUT.PUT_LINE ('Nie zmodyfikowano żadnego rekordu!');
   RAISE_APPLICATION_ERROR(-20001, 'Zespol o podanym ID nie istnieje');
  END IF;
 END ZmienDane;

 FUNCTION PokazId
 (Nazwa VARCHAR) RETURN zespoly.id_zesp%TYPE IS
 vId zespoly.id_zesp%TYPE;
 BEGIN
  SELECT id_zesp 
  INTO vId
  FROM zespoly 
  WHERE nazwa = Nazwa;
  RETURN vId;
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  RAISE_APPLICATION_ERROR(-20002, 'Zespol o podanej nazwie nie istnieje');
 END PokazId;

 FUNCTION PokazNazwe
 (Id NUMBER) RETURN zespoly.nazwa%TYPE IS
 vNazwa zespoly.nazwa%TYPE;
 BEGIN
  SELECT nazwa 
  INTO vNazwa 
  FROM zespoly 
  WHERE id_zesp = Id;
  RETURN vNazwa;
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  RAISE_APPLICATION_ERROR(-20001, 'Zespol o podanym ID nie istnieje');
 END PokazNazwe;

 FUNCTION PokazAdres
 (Id NUMBER) RETURN zespoly.adres%TYPE IS
 vAdres zespoly.adres%TYPE;
 BEGIN
  SELECT adres 
  INTO vAdres 
  FROM zespoly
  WHERE id_zesp = Id;
  RETURN vAdres;
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  RAISE_APPLICATION_ERROR(-20001, 'Zespol o podanym ID nie istnieje');
 END PokazAdres;

END IntZespoly;
/

