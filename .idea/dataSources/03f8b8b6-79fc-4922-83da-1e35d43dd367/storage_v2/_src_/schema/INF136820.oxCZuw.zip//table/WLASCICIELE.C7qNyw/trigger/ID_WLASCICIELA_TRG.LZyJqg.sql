create trigger ID_WLASCICIELA_TRG
    before insert
    on WLASCICIELE
    for each row
    when (new.id_wlasciciela IS NULL)
BEGIN
    :new.id_wlasciciela := id_wlasciciela_seq.nextval;
END;
/

