create PROCEDURE PokazPracownikaEtatu 
 (vEtat IN VARCHAR) IS
 CURSOR cPracownicyEtatu(pNazwaEtatu VARCHAR := vEtat) IS
 SELECT nazwisko
 FROM pracownicy
 WHERE etat = pNazwaEtatu;
BEGIN
  FOR vPracownik IN cPracownicyEtatu LOOP
   DBMS_OUTPUT.PUT_LINE(vPracownik.nazwisko);
  END LOOP;
END PokazPracownikaEtatu;

--EXEC PokazPracownikaEtatu('STAZYSTA');
/

